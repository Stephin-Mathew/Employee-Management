import * as echarts from 'echarts/core';
import { provideEchartsCore } from 'ngx-echarts';
import {
  ApplicationConfig,
  inject,
  provideAppInitializer,
  provideBrowserGlobalErrorListeners,
} from '@angular/core';

import { provideRouter } from '@angular/router';
import {provideHttpClient} from '@angular/common/http'

import { routes } from './app.routes';
import { AuthService } from './services/auth.service';
import { EmployeeService } from './services/employee.service';

export const appConfig: ApplicationConfig = {
  providers: [
  provideBrowserGlobalErrorListeners(),
  provideHttpClient(),
  provideRouter(routes),
  provideEchartsCore({ echarts }),

  provideAppInitializer(() => {
    const authService = inject(AuthService);
    authService.isLoggedIn();

    const emplService = inject(EmployeeService);
    return emplService.initialize();
  }),
],
};
